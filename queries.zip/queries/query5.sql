SELECT AVG(rating) as average_rating
FROM MatchSession;

-- Comments:
-- SELECT the average rating of all match sessions with AVG(rating) from the MatchSession table and name the column as average_rating.
