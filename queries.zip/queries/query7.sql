INSERT INTO Position (position_ID, position_name)
VALUES (5, 'Middle Hitter');

-- Comments:
-- position_ID and position_name information are kept in the Position table.
-- So, we inserted (5, 'Middle Hitter') row into the Position table with INSERT INTO.